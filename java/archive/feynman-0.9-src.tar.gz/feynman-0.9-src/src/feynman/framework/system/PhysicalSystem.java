/*
 * $Header: /cvsroot/feynman/src/feynman/framework/system/PhysicalSystem.java,v 1.1.1.1 2002/11/12 02:25:43 wesley_bailey Exp $
 * $Revision: 1.1.1.1 $
 * $Date: 2002/11/12 02:25:43 $
 * $Copyright: Copyright (C) 2002 Path Integral Software $
 */
package feynman.framework.system;

import java.util.Iterator;
import java.util.HashSet;
import java.util.Set;

/**
 * A <b>ObjectSystem</b> is a collection of <b>Objects</b> that are being studied.
 * This Interface describes the operations that can be performed on the system.
 *
 * @author Wes Bailey
 * @version $Revision: 1.1.1.1 $ $Date: 2002/11/12 02:25:43 $
 */
abstract public class PhysicalSystem {

	// Use a set implementation for now.
	Set system = new HashSet();

	// Package Private constructor to enforce creation of objects through the 
	//   appropriate Factory class.
	PhysicalSystem() {
		// null
	}
	
	/**
	 * Use this method to query if a Object is part of the system.
	 */
	public boolean contains(Object item) {
		if (system.contains(item)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Override this method to add an object of your defined type to the system.
	 */
	abstract public boolean add(Object item);

	/**
	 * Use this method to remove a Object from the system.
	 */
	public boolean remove(Object item) {
		if (system.remove(item)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Use this method to determine the number of Objects in the system.
	 */
	public int size() {
		return system.size();
	}

	/**
	 * Use this method to query the system to see if there are any objects in it.
	 */
	public boolean isEmpty() {
		return system.isEmpty();
	}

	/**
	 * Use this method to get and iterator over all objects in the system.
	 * <p>
	 * <b>NOTE: </b> This method is preferred to using and array or other means to accomplish
	 * the task of looping through the objects in the system.
	 */
	public Iterator iterator() {
		return system.iterator();
	}

}